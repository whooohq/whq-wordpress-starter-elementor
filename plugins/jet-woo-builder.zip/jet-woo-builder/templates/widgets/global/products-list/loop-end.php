<?php
/**
 * Products list widget loop end template.
 */
?>
</ul>
