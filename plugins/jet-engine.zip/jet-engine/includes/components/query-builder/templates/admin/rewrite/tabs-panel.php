<div class="cx-vui-tabs-panel" v-if="show">
	<slot></slot>
</div>